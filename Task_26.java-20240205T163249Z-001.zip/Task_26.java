package Tasks;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Task_26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataInputStream dis = new DataInputStream(System.in);
		FileOutputStream fos;
		FileInputStream fis;
		FileOutputStream fosmod;
		
		try {
			fos = new FileOutputStream("sen.txt");
			System.out.println("Give me the Input: ");
			char ch;
			while((ch = (char)dis.read()) != '.') {
				fos.write(ch);
			}
			fos.close();
			dis.close();
			
			fis = new FileInputStream("sen.txt");
			fosmod = new FileOutputStream("senmod.txt");
			int th;
			while((th = fis.read())!=-1) {
				if(th != 'a') {
					fosmod.write((char)th);
					System.out.print((char)th);
				}
			}
			fosmod.close();
			fis.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}

}
